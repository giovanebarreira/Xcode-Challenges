//
//  ViewController.swift
//  SimpleApp
//
//  Created by GIOVANE PASCHUALLETO BARREIRA on 27/11/17.
//  Copyright © 2017 GIOVANE PASCHUALLETO BARREIRA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var fahrenheitLabel: UILabel!
    @IBOutlet weak var celsiusTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    @IBAction func convertToFahrenheit(_ sender: Any) {
        let celsius = Double (celsiusTextField.text!)
        let fahrenheit = celsius! * (9/5) + 32
        fahrenheitLabel.text = String(fahrenheit)
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

