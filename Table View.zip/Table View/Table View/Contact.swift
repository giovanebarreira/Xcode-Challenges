//
//  Contact.swift
//  Table View
//
//  Created by GIOVANE PASCHUALLETO BARREIRA on 30/11/17.
//  Copyright © 2017 GIOVANE PASCHUALLETO BARREIRA. All rights reserved.
//

import Foundation
import UIKit

//Contact Model

class Contact{
    var name: String?
    var lastName: String?
    var picture: UIImage?
    var email: String?
    var phoneNumber: Int?
    
    
}
