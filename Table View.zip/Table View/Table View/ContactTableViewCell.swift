//
//  ContactTableViewCell.swift
//  Table View
//
//  Created by GIOVANE PASCHUALLETO BARREIRA on 30/11/17.
//  Copyright © 2017 GIOVANE PASCHUALLETO BARREIRA. All rights reserved.
//

import UIKit

class ContactTableViewCell: UITableViewCell {

    @IBOutlet weak var contactImage: UIImageView!
    @IBOutlet weak var contactName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

   
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
