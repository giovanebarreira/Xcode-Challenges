//
//  ProfileViewController.swift
//  Table View
//
//  Created by GIOVANE PASCHUALLETO BARREIRA on 30/11/17.
//  Copyright © 2017 GIOVANE PASCHUALLETO BARREIRA. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    
    var contact: Contact? // This contact will be received from tableView
    @IBOutlet weak var contactImage: UIImageView!
    
    @IBOutlet weak var lastName: UILabel!
    @IBOutlet weak var name: UILabel!
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        contactImage.image = contact?.picture
        name.text = contact?.name
        lastName.text = contact?.lastName
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view..
   
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
