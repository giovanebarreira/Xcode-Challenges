//
//  ViewController.swift
//  AlcoolOuGasolina
//
//  Created by GIOVANE PASCHUALLETO BARREIRA on 27/11/17.
//  Copyright © 2017 GIOVANE PASCHUALLETO BARREIRA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var gasolinaTextField: UITextField!
    @IBOutlet weak var alcoolTextField: UITextField!
    @IBOutlet weak var relacaoPorcentagem: UILabel!
    @IBOutlet weak var showAdviceText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func calculateButton(_ sender: Any) {
        let gasolina = Double(gasolinaTextField.text!)
        let alcool = Double(alcoolTextField.text!)
        
        if alcool == nil || gasolina == nil || alcool == 0 || gasolina == 0 || alcool! < 0 || gasolina! < 0{
            showAdviceText.text = " Preencha as informações corretamente. "
        } else {
            let calculo = (alcool! / gasolina!) * 100
            
            //label recebendo resultado da conta convertido
            relacaoPorcentagem.text = String(format: "%.2f", calculo) + "%"
            
            if calculo < 70 {
                showAdviceText.text = " Abasteça com Alcool! "
            } else{
                showAdviceText.text = " Abasteça com Gasolina! "
            }
        }

    }


    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
