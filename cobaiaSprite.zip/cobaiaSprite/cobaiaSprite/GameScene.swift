//
//  GameScene.swift
//  cobaiaSprite
//
//  Created by GIOVANE PASCHUALLETO BARREIRA on 04/12/17.
//  Copyright © 2017 GIOVANE PASCHUALLETO BARREIRA. All rights reserved.
//

import SpriteKit


class GameScene: SKScene {
    var label: SKLabelNode!
    var sprite: SKSpriteNode!
    var atlas: SKTextureAtlas!
    
    var previousTime: TimeInterval = 0
    var firstTime = true
    
    override func didMove(to view: SKView) {
        scaleMode = .aspectFit
        backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        size = CGSize(width: 720, height: 1280)
        
        label = SKLabelNode(text: "Vamo la")
        addChild(label)
        
        label.fontColor = #colorLiteral(red: 0.05882352963, green: 0.180392161, blue: 0.2470588237, alpha: 1)
        label.position = CGPoint(x: size.width/2, y: -100)
        label.fontSize = 72
        label.zPosition = 1
        
        let action = SKAction.move(by: CGVector.init(dx: 0, dy: 60), duration: 1)
        let action2 = SKAction.repeatForever(action)
        label.run(action2)
        
        //let texture = SKTexture(imageNamed: "Stalin")
        atlas = SKTextureAtlas.init(named: "Imagens")
        
        sprite = SKSpriteNode(texture: atlas.textureNamed("Margot"))
        sprite.size = CGSize(width: 250, height: 250)
        //sprite = SKSpriteNode.init(texture: texture)
        addChild(sprite)
        
        sprite.position = label.position
     
        sprite.position = CGPoint(x: size.width/2, y: size.height/2)
        sprite.zPosition = 0
        
        
        let spriteList = [
            atlas.textureNamed("Margot"),
            atlas.textureNamed("Scarlet"),]
    
        
        let spriteAction = SKAction.animate(with: spriteList, timePerFrame: 0.5)
        sprite.run(SKAction.repeatForever(spriteAction))
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        let deltaTime: CGFloat
        
        if firstTime {
            firstTime = false
            deltaTime = 1/60
        }else{
            deltaTime = CGFloat(currentTime - previousTime)
        }
        
       
        previousTime = currentTime
        
        //label.position.y += deltaTime * 60
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches{
           let pos = touch.location(in: self)
           
            
            let touchSprite = SKSpriteNode(texture: atlas.textureNamed("Margot"))
            addChild(touchSprite)
            touchSprite.position = pos
            touchSprite.zPosition = 2
            
            //o que acontece quando clica no sprite do meio
            if nodes(at: pos).contains(sprite){
                touchSprite.color = #colorLiteral(red: 0.1294117719, green: 0.2156862766, blue: 0.06666667014, alpha: 1)
                touchSprite.colorBlendFactor = 1
                
            }
                
            //efeito do sprite
           let action = SKAction.fadeOut(withDuration: 2)
            touchSprite.run(action, completion: {
                    touchSprite.removeFromParent()
           
            })
        }

    }

}
